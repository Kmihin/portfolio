# Portfolio site, Kristjan Mihin

Personal portfolio and freelance site. Owner: Kristjan Mihin, full-stack developer (.NET / Azure / React), Slovenia.

## Stack
- Astro (static output), Tailwind CSS, TypeScript.
- Client JS: three, gsap (ScrollTrigger), lenis, loaded via <script> in Astro components. Keep scripts small and commented. No UI framework on the client.
- Design (v9, "system": a dark, modern developer site over a living 3D network): one fixed full-screen Three.js canvas behind every page (`src/scripts/network.ts`, `#net` in `Base.astro`) draws a distributed system: ~170 glowing nodes (110 on phones) joined by thin links (each node to its 3 nearest neighbours), data packets travelling along the links, wireframe icosahedron hubs on every 17th node, dust far behind for depth. The nodes have a formation per scene (`SCENES` in network.ts: cloud, sphere, layers, lattice, ring, helix, wide, core; positions and links computed once, same seed every visit) and morph between them: every section with `data-scene="name"` names its formation, `motion.ts` (`followScenes`) takes the section whose top has passed mid-screen and the next one and eases the morph between them; the whole system turns with the page progress and slowly on its own, the camera drifts closer mid-page, the pointer tilts it. Pixel ratio capped (2, phones 1.5), nothing drawn while the tab is hidden, a still first formation under reduced motion. Over the canvas: a fixed vignette (`.vignette`) and a faint light that follows the pointer (`.cursor-glow`, `--mx`/`--my` set by motion.ts). Palette (global.css): near-black navy (#06090f), pale text (#e6ebf2), muted (#8b95a7), one electric cyan accent (#3ee6ff) with violet (#7a5cff) as the second accent for the hubs and the `.grad` gradient text (one word per heading). Fonts: Geist (self-hosted, the only webfont; headings weight 600, tight tracking) and the system monospace stack for labels (`.label`, `.label-mark` adds a cyan `// `), numbers, tags (`.tag`) and the marquee. Surfaces: `.glass` (dark translucent panel, blur, 1px hairline, rounded 1.25rem, a light line along its top edge), `.shade` (a dark halo behind free text over the system). Pill buttons (`.btn-primary` cyan with a glow on hover, `.btn-secondary` outlined). Hero (`Hero.astro`): monospace status line, the name in two big lines (surname in the gradient), tagline, two buttons; the stack as monospace items with cyan dots and a scroll cue on a hairline at the bottom; on wide screens my photo (`public/hero-photo.webp`, transparent cut-out) on the right, monochrome with a cyan and violet rim light, fading out at the bottom. Then `Marquee.astro` (a slow ticker of technologies, paused on hover, static under reduced motion). Motion: `src/scripts/motion.ts` (GSAP ScrollTrigger + Lenis), hooks `data-split` (keeps a child span's classes on its words, so a `.grad` word can be split), `data-rule`, `.reveal` / `.reveal-item`, `data-enter`; facts count up with the scroll (`Facts.astro`); cards lift and a light sweeps over them on hover (CSS). Header: a pulsing cyan dot and `kristjan.mihin` in monospace, the chapter links, "Let's talk" as an outlined pill (wide screens); transparent at the top, dark glass after, hides on scroll down and returns on scroll up, marks the chapter on screen; in-page links scroll smoothly (capture-phase click handler). `html` has `overflow-x: clip`. Everything honours `prefers-reduced-motion`. Content lives in `content/`; never hardcode case-study text in components.
- Copy rules: no em/en dashes in visible text (use commas, colons, periods, or a plain hyphen for ranges); the monospace status lines, chapter numbers and the scroll cue are intended.
- Deploy target: Cloudflare Pages (static). Keep the build host-agnostic.

## Code conventions
- Simple, readable code. No clever abstractions.
- No inline styles. Tailwind utility classes or scoped component CSS.
- Small components, one responsibility each.
- Type all frontmatter with Astro content collections (`src/content.config.ts`).
- English UI. Slovenian translation may come later; keep strings in content, not in markup.

## Content rules
- The transport / logistics field I work in now is never named (I cannot take projects in that field): the e-CMR work is shown in general terms as `document-platform.md` ("Digital document exchange platform"), the ReBAC work as "Security, roles and rights for a B2B platform"; the carrier import stays hidden (`_carrier-data-import.md`, skipped by the collections). The apartment site is not named ("Holiday apartment website").
- Professional work (Trinet) is described anonymously: no client names, no screenshots with real data, no internal system names beyond what is in `content/professional/`.
- Side projects may link to GitHub repos.
- AI-assisted scaffolding (Lovable) is disclosed where used.

## Pages
- `/` is the whole site, one scroll: `#home` hero (scene cloud) -> marquee -> `#about` 01 About me (sphere: heading and three paragraphs left, a glass card with my portrait and the four values right) -> `#facts` (layers: four glass tiles with monospace counters) -> `#work` 02 Selected work (lattice: `ChapterHead.astro` + `WorkGrid.astro`, glass cards, the first two wide, each linking to its case study page) -> `#skills` 03 Tech expertise (ring: `Expertise.astro`, a numbered list on a glass panel from `content/skills.json`) -> `#offer` 04 What I offer (helix: `Offer.astro`, a bento of glass tiles from `content/services.json`) -> `#closing` statement (wide: "Experience decides what to build.") -> `#contact` 05 Let's talk (core: one big glass card with the email as the main button and the links, the footer line under it; the home page passes `footer={false}` to Base).
- Work comes from the case-study collections (featured first, then most recent).
- `/work/[slug]` is a page for every case study (scene core): label, title, gradient tagline and summary, the cover in a rounded frame, the feature grid (`CaseFeatures.astro`), a sticky glass card with role, stack tags and links beside the markdown body; a "Next" band and `Footer.astro`.

## Workflow
- Run `npm run dev` for preview, `npm run build` must pass before commit.
- Commit messages: short imperative English.
