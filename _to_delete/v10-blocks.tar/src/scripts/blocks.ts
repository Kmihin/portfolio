// The 3D scene behind the whole site (Three.js, one fixed full-screen canvas).
//
// A field of soft rounded blocks on a white floor, lit like a product shot (soft shadows). The
// blocks rise and fall into a different formation for every section of the page (waves, a tower,
// bars, tiles, a ring, a checkerboard, a spire): systems being built, block by block. Heights ease
// toward their target, so a fast scroll never snaps, and a gentle ripple keeps the field alive.
// The camera orbits a little with the page and follows the pointer.
//
//   startBlocks(canvas)   builds the scene and starts drawing; stopBlocks() before a page swap
//   setScene(a, b, t)     formation between scene a and scene b, t = 0..1 (motion.ts, on scroll)
//   setProgress(p)        page progress 0..1, orbits the camera
import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";

const BG = new THREE.Color("#f6f7fb");
const LOW = new THREE.Color("#eef1fa");
const HIGH = new THREE.Color("#93a4ff");
const CORAL = new THREE.Color("#ff8a65");

const SCENES = ["waves", "tower", "bars", "tiles", "ring", "checker", "calm", "spire"] as const;
type SceneName = (typeof SCENES)[number];

let stop: (() => void) | null = null;
let scene = { a: "waves" as SceneName, b: "waves" as SceneName, t: 0 };
let progress = 0;

export function setScene(a: string, b: string, t: number) {
  const ok = (n: string): n is SceneName => (SCENES as readonly string[]).includes(n);
  scene = { a: ok(a) ? a : "waves", b: ok(b) ? b : "waves", t: Math.min(Math.max(t, 0), 1) };
}
export function setProgress(p: number) {
  progress = Math.min(Math.max(p, 0), 1);
}
export function stopBlocks() {
  if (stop) stop();
  stop = null;
}

/** A stable pseudo-random number for a grid cell. */
function hash(x: number, z: number) {
  const s = Math.sin(x * 127.1 + z * 311.7) * 43758.5453;
  return s - Math.floor(s);
}

/** Height 0..1 of the block at grid cell (x, z), both -1..1, for a formation. */
function height(name: SceneName, x: number, z: number): number {
  const r = Math.hypot(x, z);
  switch (name) {
    case "waves":
      return 0.3 + 0.3 * Math.sin(x * 4.2 + z * 1.5) * Math.cos(z * 3.6 - x) + 0.1 * Math.sin((x + z) * 7);
    case "tower": {
      const d = Math.max(Math.abs(x), Math.abs(z));
      return d > 0.55 ? 0.08 : Math.min(1, Math.ceil((0.55 - d) * 6) / 4 + 0.1);
    }
    case "bars": {
      const col = Math.floor((x + 1) * 5);
      const row = Math.floor((z + 1) * 5);
      return 0.08 + ((col * 7 + row * 3) % 10) / 10 * 0.9;
    }
    case "tiles": {
      const cx = Math.floor((x + 1) * 3);
      const cz = Math.floor((z + 1) * 3);
      return 0.1 + hash(cx, cz) * 0.5;
    }
    case "ring":
      return 0.1 + Math.max(0, 1 - Math.abs(r - 0.6) * 5) * 0.9;
    case "checker": {
      const cx = Math.floor((x + 1) * 6);
      const cz = Math.floor((z + 1) * 6);
      return (cx + cz) % 2 === 0 ? 0.45 : 0.1;
    }
    case "calm":
      return 0.12 + 0.05 * Math.sin(x * 6) * Math.cos(z * 6);
    case "spire":
      return 0.1 + Math.max(0, 1 - r * 2.2) ** 1.5;
  }
}

export function startBlocks(canvas: HTMLCanvasElement) {
  stopBlocks();
  const small = window.innerWidth < 768;
  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: "high-performance" });
  renderer.setPixelRatio(Math.min(devicePixelRatio, small ? 1.5 : 2));
  renderer.setClearColor(BG, 1);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  const world = new THREE.Scene();
  world.fog = new THREE.Fog(BG, 52, 92);
  const camera = new THREE.PerspectiveCamera(28, 1, 1, 200);

  // Lights: a soft sky and one sun casting soft shadows.
  world.add(new THREE.HemisphereLight(0xffffff, 0xdfe6f5, 1.1));
  const sun = new THREE.DirectionalLight(0xffffff, 1.9);
  sun.position.set(14, 24, 10);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.left = sun.shadow.camera.bottom = -24;
  sun.shadow.camera.right = sun.shadow.camera.top = 24;
  sun.shadow.camera.near = 1;
  sun.shadow.camera.far = 70;
  sun.shadow.bias = -0.0005;
  sun.shadow.radius = 4;
  world.add(sun);

  // The floor only shows the shadows.
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), new THREE.ShadowMaterial({ opacity: 0.08 }));
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  world.add(floor);

  // The blocks: one instanced mesh, a grid of SIDE x SIDE.
  const SIDE = small ? 22 : 32;
  const STEP = 1.08;
  const MAX_H = 4.5;
  const count = SIDE * SIDE;
  const geometry = new RoundedBoxGeometry(0.92, 1, 0.92, 2, 0.1);
  geometry.translate(0, 0.5, 0); // base at y = 0, so scaling y grows upward
  const material = new THREE.MeshStandardMaterial({ roughness: 0.6, metalness: 0.0 });
  const blocks = new THREE.InstancedMesh(geometry, material, count);
  blocks.castShadow = true;
  blocks.receiveShadow = true;
  blocks.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(count * 3), 3);
  world.add(blocks);

  const cells: { x: number; z: number; nx: number; nz: number; coral: boolean }[] = [];
  for (let i = 0; i < count; i++) {
    const gx = i % SIDE;
    const gz = Math.floor(i / SIDE);
    const nx = (gx / (SIDE - 1)) * 2 - 1;
    const nz = (gz / (SIDE - 1)) * 2 - 1;
    cells.push({ x: (gx - (SIDE - 1) / 2) * STEP, z: (gz - (SIDE - 1) / 2) * STEP, nx, nz, coral: hash(gx + 3, gz + 7) > 0.975 });
  }
  const current = new Float32Array(count).fill(0.2);
  const matrix = new THREE.Matrix4();
  const color = new THREE.Color();

  function targetHeight(i: number) {
    const c = cells[i];
    const t = scene.t * scene.t * (3 - 2 * scene.t);
    return height(scene.a, c.nx, c.nz) * (1 - t) + height(scene.b, c.nx, c.nz) * t;
  }

  function updateBlocks(dt: number, time: number) {
    const ease = reduced ? 1 : 1 - Math.pow(0.03, dt);
    for (let i = 0; i < count; i++) {
      const c = cells[i];
      // A faint travelling ripple keeps the field alive.
      const ripple = reduced ? 0 : 0.03 * Math.sin(time * 1.2 + c.x * 0.8 + c.z * 0.6);
      const target = Math.min(Math.max(targetHeight(i), 0.05), 1);
      current[i] += (target - current[i]) * ease;
      const h = (current[i] + ripple) * MAX_H;
      matrix.makeScale(1, Math.max(h, 0.15), 1);
      matrix.setPosition(c.x, 0, c.z);
      blocks.setMatrixAt(i, matrix);
      // Colour: pale when low, blue when high; a few coral blocks for warmth.
      if (c.coral) color.copy(CORAL);
      else color.copy(LOW).lerp(HIGH, Math.pow(current[i], 1.4) * 0.85);
      blocks.setColorAt(i, color);
    }
    blocks.instanceMatrix.needsUpdate = true;
    blocks.instanceColor!.needsUpdate = true;
  }

  // Camera: an isometric-ish view from the front right, orbiting a little with the page.
  const pointer = { x: 0, y: 0 };
  const tilt = { x: 0, y: 0 };
  const CAM_R = small ? 56 : 54;
  function placeCamera() {
    const a = Math.PI * 0.22 + progress * 0.9 + tilt.x * 0.25;
    const y = (small ? 36 : 36) + tilt.y * 3;
    camera.position.set(Math.cos(a) * CAM_R, y, Math.sin(a) * CAM_R);
    // Looking left of the field (along the camera's own right axis), so the field sits under the
    // right side of the page, whatever the orbit angle. Centred on phones.
    const shift = small ? 0 : 9;
    camera.lookAt(Math.sin(a) * -shift, 1, Math.cos(a) * shift);
  }

  function resize() {
    const w = window.innerWidth;
    const h = window.innerHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.fov = w < h ? 42 : 28;
    camera.updateProjectionMatrix();
  }

  let frameId = 0;
  let last = performance.now();
  let time = 0;
  function frame(now: number) {
    const dt = Math.min((now - last) / 1000, 0.1);
    last = now;
    if (!reduced) time += dt;
    tilt.x += (pointer.x - tilt.x) * (reduced ? 1 : 0.05);
    tilt.y += (pointer.y - tilt.y) * (reduced ? 1 : 0.05);
    updateBlocks(dt, time);
    placeCamera();
    renderer.render(world, camera);
    frameId = requestAnimationFrame(frame);
  }

  function onPointer(e: PointerEvent) {
    pointer.x = e.clientX / window.innerWidth - 0.5;
    pointer.y = 0.5 - e.clientY / window.innerHeight;
  }
  function onVisibility() {
    cancelAnimationFrame(frameId);
    if (!document.hidden) {
      last = performance.now();
      frameId = requestAnimationFrame(frame);
    }
  }

  window.addEventListener("resize", resize);
  window.addEventListener("pointermove", onPointer);
  document.addEventListener("visibilitychange", onVisibility);
  resize();
  frameId = requestAnimationFrame(frame);

  stop = () => {
    cancelAnimationFrame(frameId);
    window.removeEventListener("resize", resize);
    window.removeEventListener("pointermove", onPointer);
    document.removeEventListener("visibilitychange", onVisibility);
    geometry.dispose();
    material.dispose();
    floor.geometry.dispose();
    (floor.material as THREE.Material).dispose();
    renderer.dispose();
  };
}
