# Portfolio site, Kristjan Mihin

Personal portfolio and freelance site. Owner: Kristjan Mihin, full-stack developer (.NET / Azure / React), Slovenia.

## Stack
- Astro (static output), Tailwind CSS, TypeScript.
- Client JS: three, gsap (ScrollTrigger), lenis, loaded via <script> in Astro components. Keep scripts small and commented. No UI framework on the client.
- Design (v8, "summit": a flight through a 3D mountain range): one fixed full-screen Three.js canvas behind every page (`src/scripts/summit.ts`, `#summit` in `Base.astro`) draws a procedural range: heights from ridged noise computed once on the CPU (a winding valley along the flight, taller ranges further away), coloured per pixel in a shader: deep navy rock lit from the side, snow on the high gentle slopes, thin gold veins (about a pixel wide at any distance, `fwidth`), drifting mist in the valleys and distance fog into the ivory sky (#f3ece0), plus gold dust in the air. The camera flies as the page scrolls: every section with `data-stop="name"` names a camera stop (`STOPS` in summit.ts: hero, about, facts, work, skills, offer, closing, contact, detail); `motion.ts` (`followStops`) takes the section whose top has passed mid-screen and the next one, and the camera eases between their stops; the pointer turns the view a little; on load the camera flies in from lower down. Stops keep the horizon a little above the middle of the screen, so the upper part is sky for the text. Pixel ratio capped (1.75, phones 1.5), fewer vertices and dust on phones, nothing drawn while the tab is hidden, a still camera under reduced motion. The page alternates two kinds of section: views (`.view`), where the landscape is the picture and the text sits on its sky with a `.shield` halo (hero, facts, the chapter openings `ChapterHead.astro`, the closing statement), and sheets of paper (`.sheet`, #f4ede1) for the content (about, work, expertise, offer, contact; the case study body and the footer on other pages); the landscape dissolves into each sheet through a gradient above and below it (`.sheet::before/::after`; `.sheet-end` for the last one). The text in tall views is sticky (`ChapterHead` 140dvh, facts and closing 170dvh), so it stays on the sky while the camera flies on and the next sheet rises over it like mist. Palette: ivory sky and paper, navy ink (#0d172b), brass (#a6814e, light #c9a86a) for the surname, the italic second part of headings, chapter numbers on a short brass line, the main button, link underlines and icons. Fonts self-hosted via @fontsource-variable: Bodoni Moda (display; the big headings at weight 600) + Geist (body). Sharp corners. Hero (`Hero.astro`): role, name with the surname in brass, line, "View my work" and "About me" on the sky; my photo (`public/hero-photo.webp`, a transparent cut-out) on the right standing in the landscape, its lower part fading into the mist; the stack on a brass line and a scroll cue at the bottom (wide screens only). Motion: `src/scripts/motion.ts` (GSAP ScrollTrigger + Lenis), hooks `data-split`, `data-rule`, `.reveal` / `.reveal-item`, `data-enter`; facts count up with the scroll (`Facts.astro`). Header: KM monogram, the chapter links, "Let's talk" on the right; transparent at the top, a paper surface after, hides on scroll down and returns on scroll up, marks the chapter on screen; in-page links scroll smoothly (capture-phase click handler). Layers: the canvas at -1; anything that must stay above a sheet's misty edge (the hero foot, the "Next" band on case studies) gets `position: relative; z-index: 1`. `html` has `overflow-x: clip`. Everything honours `prefers-reduced-motion`. Content lives in `content/`; never hardcode case-study text in components.
- Copy rules: no em/en dashes in visible text (use commas, colons, periods, or a plain hyphen for ranges); the hero eyebrow, chapter numbers and the scroll mark from my mockup are intended.
- Deploy target: Cloudflare Pages (static). Keep the build host-agnostic.

## Code conventions
- Simple, readable code. No clever abstractions.
- No inline styles. Tailwind utility classes or scoped component CSS.
- Small components, one responsibility each.
- Type all frontmatter with Astro content collections (`src/content.config.ts`).
- English UI. Slovenian translation may come later; keep strings in content, not in markup.

## Content rules
- The transport / logistics field I work in now is never named (I cannot take projects in that field): the e-CMR work is shown in general terms as `document-platform.md` ("Digital document exchange platform"), the ReBAC work as "Security, roles and rights for a B2B platform"; the carrier import stays hidden (`_carrier-data-import.md`, skipped by the collections). The apartment site is not named ("Holiday apartment website").
- Professional work (Trinet) is described anonymously: no client names, no screenshots with real data, no internal system names beyond what is in `content/professional/`.
- Side projects may link to GitHub repos.
- AI-assisted scaffolding (Lovable) is disclosed where used.

## Pages
- `/` is the whole site, one scroll: `#home` hero (view) -> `#about` 01 About me (sheet: heading, three paragraphs, four values with line icons) -> facts (view, four brass counters) -> `#work` 02 Selected Work (opening view + sheet: `WorkList.astro`, one row per case study linking to its page) -> `#skills` 03 Tech Expertise (view + sheet: `Expertise.astro` grid from `content/skills.json`) -> `#offer` 04 What I Offer (view + sheet: `Offer.astro` list from `content/services.json`) -> `#closing` statement (view: "Experience decides what to build." and two sentences) -> `#contact` 05 Let's talk with the footer line (last sheet; the home page passes `footer={false}` to Base).
- Work comes from the case-study collections (featured first, then most recent).
- `/work/[slug]` is a page for every case study: title, tagline and summary on the sky, then a sheet with the cover, the feature grid (`CaseFeatures.astro`), role, stack and links, the markdown body; a navy "Next" band and the footer.

## Workflow
- Run `npm run dev` for preview, `npm run build` must pass before commit.
- Commit messages: short imperative English.
