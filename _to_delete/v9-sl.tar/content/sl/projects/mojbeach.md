---
title: "MojBeach: rezervacije igrišč za odbojko na mivki"
label: MojBeach
slug: mojbeach
type: project
year: 2026
summary: Platforma za rezervacije igrišč za odbojko na mivki v Sloveniji, s cenikom, ponavljajočimi se rezervacijami in upravljanjem za lokacije.
stack: [React 19, TanStack Start, TypeScript, Tailwind, "Supabase (Postgres, Auth, RLS)", Resend, Cloudflare Workers]
role: Zasnova, podatkovni model, izvedba
links: { repo: "https://github.com/Kmihin/mojbeach-3b22da5a", live: "https://mojbeach.si" }
featured: true
---

## Izziv
Lastna ideja za produkt: lokacije z igrišči za odbojko na mivki v Sloveniji rezervacije urejajo po telefonu ali sporočilih. MojBeach lokaciji da javno stran za rezervacije in upravljanje cen, ponavljajočih se rezervacij in zapor, igralci pa za rezervacijo ne potrebujejo računa.

## Kaj sem naredil
- Podatkovni model: lokacije, igrišča, delovni čas, rezervacije, zaprti termini, cenovni pasovi, ponavljajoče se skupine, turnirji (12 tabel, 29 migracij).
- Poslovna logika v približno 25 funkcijah Postgres: `create_booking`, `calc_booking_price`, `preview_recurring_conflicts`, `create_bulk_blocks` in druge; RLS za javnost, lastnike in skrbnike.
- Javni del: koledar, izbira termina, sprotni izračun cene, rezervacija brez računa, odpoved s kodo, prijava na turnir.
- Upravljanje: načini cen (enotna cena ali časovni pasovi za delavnike in vikende), ročne in ponavljajoče se rezervacije s predogledom prekrivanj, zapiranje več terminov hkrati, stanje plačil, vloge.
- Transakcijska e-pošta (Resend) v slovenščini; funkcije samo na strežniku.
- Ogrodje narejeno z Lovable, nato specificirano in razširjeno v štirih fazah (dodajne migracije, RLS povsod).

## Rezultat
Deluje na mojbeach.si kot produkt, pripravljen za uporabo; nobena lokacija ga še ne uporablja. Predstavljen kot demo produkta: celoten potek rezervacije, cenik in upravljanje delujejo.
