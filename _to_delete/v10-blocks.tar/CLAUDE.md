# Portfolio site, Kristjan Mihin

Personal portfolio and freelance site. Owner: Kristjan Mihin, full-stack developer (.NET / Azure / React), Slovenia.

## Stack
- Astro (static output), Tailwind CSS, TypeScript.
- Client JS: three, gsap (ScrollTrigger), lenis, loaded via <script> in Astro components. Keep scripts small and commented. No UI framework on the client.
- Design (v10, "blocks": a light, clean developer site over a 3D field of building blocks): one fixed full-screen Three.js canvas behind every page (`src/scripts/blocks.ts`, `#blocks` in `Base.astro`) draws a 32 x 32 grid of soft rounded blocks (22 x 22 on phones; one InstancedMesh with `RoundedBoxGeometry` from three/examples) on a white floor, lit by a hemisphere light and one sun with soft shadows (PCFSoft, a `ShadowMaterial` floor), fog into the page colour. Every block has a height per scene (`height()` in blocks.ts: waves, tower, bars, tiles, ring, checker, calm, spire) and the field morphs between them: every section with `data-scene="name"` names its formation, `motion.ts` (`followScenes`) takes the section whose top has passed mid-screen and the next one and eases the heights between them; a faint ripple keeps the field alive; the camera orbits a little with the page progress and tilts with the pointer, looking right of centre so the field sits under the right side of the page. Colours: pale when low, indigo when high, a few coral blocks. Pixel ratio capped (2, phones 1.5), nothing drawn while the tab is hidden, a still first formation under reduced motion. Over the canvas a fixed white haze (`.haze`) over the left side and the top and bottom edges, so text on the left always sits on calm ground. Palette (global.css): off-white (#f6f7fb), white surfaces, slate ink (#0f172a), muted (#5b6475), one indigo-blue accent (#3b5bfd, soft #e8ecff) and coral (#ff8a65) as a small second accent. Fonts: Geist (self-hosted, the only webfont; headings weight 600, tight tracking) and the system monospace stack for labels (`.label`, `.label-mark` adds an accent `// `), code, numbers and tags (`.tag`, indigo on soft indigo). Surfaces: `.card` (white, 1px hairline, rounded 1.5rem, soft shadow; `--shadow-lift` on hover). Rounded buttons (`.btn-primary` indigo with a blue shadow, `.btn-secondary` white outlined); `.hl` colours the one accent word of a heading. Hero (`Hero.astro`): monospace line, the name in two big lines (surname in the accent), tagline, two buttons; on the right a small editor window (`developer.ts`) showing me as an object literal, typed line by line on load with a blinking caret (all values are facts from the page); the stack with accent dots and a scroll cue on a hairline at the bottom. Motion: `src/scripts/motion.ts` (GSAP ScrollTrigger + Lenis), hooks `data-split` (keeps a child span's classes on its words, so an `.hl` word can be split), `data-rule`, `.reveal` / `.reveal-item`, `data-enter`; facts count up with the scroll (`Facts.astro`); cards lift with a blue shadow on hover (CSS). Header (`Header.astro`): a floating white pill with the KM monogram, the chapter links (the one on screen gets a soft indigo pill) and "Let's talk" (wide screens); hides on scroll down and returns on scroll up; in-page links scroll smoothly (capture-phase click handler). `html` has `overflow-x: clip`. Everything honours `prefers-reduced-motion`. Content lives in `content/`; never hardcode case-study text in components.
- Copy rules: no em/en dashes in visible text (use commas, colons, periods, or a plain hyphen for ranges); the monospace status lines, chapter numbers and the scroll cue are intended.
- Deploy target: Cloudflare Pages (static). Keep the build host-agnostic.

## Code conventions
- Simple, readable code. No clever abstractions.
- No inline styles. Tailwind utility classes or scoped component CSS.
- Small components, one responsibility each.
- Type all frontmatter with Astro content collections (`src/content.config.ts`).
- English UI. Slovenian translation may come later; keep strings in content, not in markup.

## Content rules
- The transport / logistics field I work in now is never named (I cannot take projects in that field): the e-CMR work is shown in general terms as `document-platform.md` ("Digital document exchange platform"), the ReBAC work as "Security, roles and rights for a B2B platform"; the carrier import stays hidden (`_carrier-data-import.md`, skipped by the collections). The apartment site is not named ("Holiday apartment website").
- Professional work (Trinet) is described anonymously: no client names, no screenshots with real data, no internal system names beyond what is in `content/professional/`.
- Side projects may link to GitHub repos.
- AI-assisted scaffolding (Lovable) is disclosed where used.

## Pages
- `/` is the whole site, one scroll: `#home` hero (scene waves) -> `#about` 01 About me (tower: a turned white card with my portrait and a coral location sticker left; heading, three paragraphs and the four values as chips with line icons right) -> `#facts` (bars: one white card split into four counters) -> `#work` 02 Selected work (tiles: `ChapterHead.astro` + `WorkGrid.astro`, white cards, the first two wide, each linking to its case study page) -> `#skills` 03 Tech expertise (ring: `Expertise.astro`, a numbered list in a white card from `content/skills.json`) -> `#offer` 04 What I offer (checker: `Offer.astro`, a bento of white tiles from `content/services.json`) -> `#closing` statement (calm, centred: "Experience decides what to build.") -> `#contact` 05 (spire: one big indigo card, "Let's build something.", the email as a white button and the links; the footer line under it; the home page passes `footer={false}` to Base).
- Work comes from the case-study collections (featured first, then most recent).
- `/work/[slug]` is a page for every case study (scene spire): label, title, accent tagline and summary, the cover in a rounded frame, the feature grid (`CaseFeatures.astro`), a sticky white card with role, stack tags and links beside the markdown body; a "Next" band and `Footer.astro`.

## Workflow
- Run `npm run dev` for preview, `npm run build` must pass before commit.
- Commit messages: short imperative English.
